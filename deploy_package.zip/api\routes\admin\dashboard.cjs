const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config({ path: path.join(__dirname, '../../../.env') });

const dbConfig = {
    host: process.env.DB_HOST || 'srv1196.hstgr.io',
    port: parseInt(process.env.DB_PORT || '3306'),
    user: process.env.DB_USER || 'u689528678_SSALAZARCA',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'u689528678_CAFECOLOMBIA',
    ssl: { rejectUnauthorized: false }
};

// GET /api/admin/dashboard/stats - EXPANDIDO CON MÉTRICAS ÚTILES
router.get('/stats', async (req, res) => {
    try {
        const connection = await mysql.createConnection(dbConfig);

        // Métricas de Usuarios
        const [usersCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM users WHERE isActive = 1'
        );

        const [adminsCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM users WHERE role = "ADMINISTRADOR" AND isActive = 1'
        );

        const [workersCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM users WHERE role = "TRABAJADOR" AND isActive = 1'
        );

        const [newUsersCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM users WHERE createdAt >= DATE_SUB(NOW(), INTERVAL 30 DAY)'
        );

        // Métricas de Fincas y Lotes
        const [farmsCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM farms WHERE isActive = 1'
        );

        const [lotsCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM lots WHERE isActive = 1'
        );

        const [totalArea] = await connection.execute(
            'SELECT COALESCE(SUM(area), 0) as total FROM farms WHERE isActive = 1'
        );

        // Métricas de Producción
        const [totalProduction] = await connection.execute(
            'SELECT COALESCE(SUM(quantityKg), 0) as total FROM harvests'
        );

        const [monthlyProduction] = await connection.execute(
            'SELECT COALESCE(SUM(quantityKg), 0) as total FROM harvests WHERE MONTH(harvestDate) = MONTH(NOW()) AND YEAR(harvestDate) = YEAR(NOW())'
        );

        // Métricas Financieras
        const [monthlyExpenses] = await connection.execute(
            'SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE MONTH(date) = MONTH(NOW()) AND YEAR(date) = YEAR(NOW())'
        );

        // Métricas de Calidad
        const [avgQuality] = await connection.execute(
            'SELECT COALESCE(AVG(scaScore), 0) as average FROM quality_controls WHERE scaScore IS NOT NULL'
        );

        const [microlotsCount] = await connection.execute(
            'SELECT COUNT(*) as count FROM microlots WHERE isActive = 1'
        );

        await connection.end();

        res.json({
            // Métricas de usuarios
            users: usersCount[0].count,
            admins: adminsCount[0].count,
            workers: workersCount[0].count,
            newUsersThisMonth: newUsersCount[0].count,

            // Métricas de fincas y lotes
            farms: farmsCount[0].count,
            lots: lotsCount[0].count,
            totalCultivatedArea: parseFloat(totalArea[0].total.toFixed(2)),

            // Métricas de producción
            totalProduction: parseFloat(totalProduction[0].total.toFixed(2)),
            monthlyProduction: parseFloat(monthlyProduction[0].total.toFixed(2)),

            // Métricas financieras
            monthlyExpenses: parseFloat(monthlyExpenses[0].total.toFixed(2)),

            // Métricas de calidad
            averageQuality: parseFloat(avgQuality[0].average.toFixed(2)),
            microlots: microlotsCount[0].count,

            // Metadata
            configurations: 15,
            lastUpdate: new Date().toISOString()
        });
    } catch (error) {
        console.error('Error obteniendo estadísticas:', error);
        res.status(500).json({ error: 'Error obteniendo estadísticas' });
    }
});

// GET /api/admin/dashboard/charts - EXPANDIDO CON GRÁFICOS ADICIONALES
router.get('/charts', async (req, res) => {
    try {
        const period = req.query.period || '30d';
        const connection = await mysql.createConnection(dbConfig);

        // Calcular fecha de inicio según el período
        let daysAgo = 30;
        if (period === '7d') daysAgo = 7;
        else if (period === '90d') daysAgo = 90;
        else if (period === '1y') daysAgo = 365;

        // Crecimiento de usuarios
        const [userGrowth] = await connection.execute(`
      SELECT 
        DATE(createdAt) as date,
        COUNT(*) as users
      FROM users
      WHERE createdAt >= DATE_SUB(NOW(), INTERVAL ? DAY)
      GROUP BY DATE(createdAt)
      ORDER BY date ASC
    `, [daysAgo]);

        // Distribución por rol
        const [roleDistribution] = await connection.execute(`
      SELECT 
        role as name,
        COUNT(*) as value
      FROM users
      GROUP BY role
    `);

        // Producción mensual (últimos 6 meses)
        const [productionData] = await connection.execute(`
      SELECT 
        DATE_FORMAT(harvestDate, '%b') as month,
        COALESCE(SUM(quantityKg), 0) as production
      FROM harvests
      WHERE harvestDate >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
      GROUP BY DATE_FORMAT(harvestDate, '%Y-%m'), DATE_FORMAT(harvestDate, '%b')
      ORDER BY DATE_FORMAT(harvestDate, '%Y-%m') ASC
      LIMIT 6
    `);

        // Fincas por ubicación
        const [farmsByLocation] = await connection.execute(`
      SELECT 
        location as name,
        COUNT(*) as count
      FROM farms
      WHERE isActive = 1
      GROUP BY location
      ORDER BY count DESC
      LIMIT 10
    `);

        // Gastos por categoría (mes actual)
        const [expensesByCategory] = await connection.execute(`
      SELECT 
        category as name,
        COALESCE(SUM(amount), 0) as value
      FROM expenses
      WHERE MONTH(date) = MONTH(NOW()) AND YEAR(date) = YEAR(NOW())
      GROUP BY category
    `);

        // Distribución de calidad SCA
        const [qualityDistribution] = await connection.execute(`
      SELECT 
        CASE 
          WHEN scaScore >= 90 THEN 'Excepcional (90+)'
          WHEN scaScore >= 85 THEN 'Excelente (85-89)'
          WHEN scaScore >= 80 THEN 'Muy Bueno (80-84)'
          ELSE 'Bueno (<80)'
        END as grade,
        COUNT(*) as count
      FROM quality_controls
      WHERE scaScore IS NOT NULL
      GROUP BY grade
      ORDER BY MIN(scaScore) DESC
    `);

        await connection.end();

        const chartData = {
            userGrowth: userGrowth.map(row => ({
                date: row.date,
                users: row.users
            })),
            subscriptionDistribution: roleDistribution.map(row => ({
                name: row.name,
                value: row.value
            })),
            productionTrend: productionData.map(row => ({
                month: row.month,
                production: parseFloat(row.production)
            })),
            farmsByLocation: farmsByLocation.map(row => ({
                name: row.name,
                count: row.count
            })),
            expensesByCategory: expensesByCategory.map(row => ({
                name: row.name,
                value: parseFloat(row.value)
            })),
            qualityDistribution: qualityDistribution.map(row => ({
                grade: row.grade,
                count: row.count
            })),
            revenueData: productionData.map(row => ({
                month: row.month,
                revenue: parseFloat(row.production) * 10 // Estimación: 10 pesos por kg
            })),
            period: period,
            lastUpdate: new Date().toISOString()
        };

        res.json(chartData);
    } catch (error) {
        console.error('Error obteniendo datos de gráficos:', error);
        res.status(500).json({ error: 'Error obteniendo datos de gráficos' });
    }
});

module.exports = router;
